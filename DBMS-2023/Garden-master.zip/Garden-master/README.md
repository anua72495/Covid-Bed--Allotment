Garden
======

Garden is an OpenGL project. I did this as a Graphics Lab assignment. I thoroughly enjoyed doing this assignment.

After running the program, press following for respective effects
b : add a weird butterfly
f : add a weird flower tree
w : toggle wind
space key : toggle camera rotation
arrow keys : navigation
